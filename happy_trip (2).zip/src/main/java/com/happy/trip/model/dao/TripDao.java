package com.happy.trip.model.dao;

import java.sql.SQLException;

import com.happy.trip.model.dto.TripDto;
import com.happy.trip.model.dto.TripSearchDto;

public interface TripDao {
	TripDto searchByParam(TripSearchDto param) throws SQLException;
}
