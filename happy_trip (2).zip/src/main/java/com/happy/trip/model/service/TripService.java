package com.happy.trip.model.service;

import java.util.List;

import com.happy.trip.model.dto.TripDto;

public interface TripService {
	List<TripDto> searchArea(TripDto tripDto);
}
