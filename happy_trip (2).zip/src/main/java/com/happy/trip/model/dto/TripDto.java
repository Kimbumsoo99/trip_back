package com.happy.trip.model.dto;

public class TripDto {
	String contentTypeId;
	String title;
	String addr1;
	String firstImage;
	int sidoCode;
	int gugunCode;
	double latitude;
	double longitude;

	public TripDto(String contentTypeId, String title, String addr1, String firstImage, int sidoCode, int gugunCode,
			double latitude, double longitude) {
		super();
		this.contentTypeId = contentTypeId;
		this.title = title;
		this.addr1 = addr1;
		this.firstImage = firstImage;
		this.sidoCode = sidoCode;
		this.gugunCode = gugunCode;
		this.latitude = latitude;
		this.longitude = longitude;
	}

	public TripDto() {
		super();
	}

	@Override
	public String toString() {
		return "TripDto [contentTypeId=" + contentTypeId + ", title=" + title + ", addr1=" + addr1 + ", firstImage="
				+ firstImage + ", sidoCode=" + sidoCode + ", gugunCode=" + gugunCode + ", latitude=" + latitude
				+ ", longitude=" + longitude + "]";
	}

}
