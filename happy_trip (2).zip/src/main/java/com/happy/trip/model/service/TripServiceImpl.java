package com.happy.trip.model.service;

import java.util.List;

import com.happy.trip.model.dao.TripDao;
import com.happy.trip.model.dao.TripDaoImpl;
import com.happy.trip.model.dto.TripDto;

public class TripServiceImpl implements TripService{
	TripDao tripDao = TripDaoImpl.getInstance();
	private static TripService instance = new TripServiceImpl();
	private TripServiceImpl() {}
	public static TripService getInstance() {
		return instance;
	}
	@Override
	public List<TripDto> searchArea(TripDto tripDto) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
