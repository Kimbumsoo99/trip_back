package com.happy.trip.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.happy.trip.model.dto.TripDto;
import com.happy.trip.model.dto.TripSearchDto;
import com.happy.util.DBUtil;

public class TripDaoImpl implements TripDao {
	private DBUtil dbUtil = DBUtil.getInstance();
	static private TripDao instance = new TripDaoImpl();

	private TripDaoImpl() {
	}

	static public TripDao getInstance() {
		return instance;
	}

	@Override
	public TripDto searchByParam(TripSearchDto param) throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		TripDto tripDto = new TripDto();
		try {
			con = dbUtil.getConnection();
			String sql = "";
			ps = con.prepareStatement(sql);
			return null;
		} catch (SQLException e) {
			throw e;
		} finally {
			dbUtil.close(rs, ps, con);
		}
	}

}
