package com.happy.member.model.dao;

public interface MemberDao {

}
