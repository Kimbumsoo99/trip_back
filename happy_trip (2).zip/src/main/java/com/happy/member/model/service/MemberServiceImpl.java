package com.happy.member.model.service;

public class MemberServiceImpl {

}
