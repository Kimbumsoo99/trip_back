package com.happy.member.model.service;

public interface MemberService {

}
