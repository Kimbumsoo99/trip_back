package com.happy.member.model.dto;

public class MemberDto {

}
