package com.happy.member.model.dao;

public class MemberDaoImpl implements MemberDao{

}
