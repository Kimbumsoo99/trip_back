package com.happy.board.model.service;

public class BoardServiceImpl {

}
