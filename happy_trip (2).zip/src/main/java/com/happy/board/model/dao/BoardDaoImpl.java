package com.happy.board.model.dao;

public class BoardDaoImpl {

}
