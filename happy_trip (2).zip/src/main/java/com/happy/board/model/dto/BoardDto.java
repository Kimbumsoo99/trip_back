package com.happy.board.model.dto;

public class BoardDto {

}
