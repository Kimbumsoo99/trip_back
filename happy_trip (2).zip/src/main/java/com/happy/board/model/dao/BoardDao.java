package com.happy.board.model.dao;

public interface BoardDao {

}
